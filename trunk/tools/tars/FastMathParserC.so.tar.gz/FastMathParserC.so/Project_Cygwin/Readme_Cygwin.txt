########################################################
#						       #		
#   Mathematical expressions parser library            #
#                                                      #  
#   Copyright (c) 2004, 2005 Ingo Berg                 #
#                            ingo_berg{at}gmx.de       #
#                                                      #  
########################################################

I got plenty of feedback indicating that many users use this parser with GNU-C++. For this reason I provide you with a GNU Makefile. This Makefile will create a static library and build a sample application. It uses the file example1.cpp which is also used in the first MSVC example.

To create the example just type:
"make new"



