########################################################
#						       #		
#   Mathematical expressions parser library            #
#                                                      #  
#   Copyright (c) 2004, 2005 Ingo Berg                 #
#                            ingo_berg{at}gmx.de       #
#                                                      #  
########################################################

I got a lot of feedback from BCB users. For this reason I provide you with 
Borland project files. I'd like to thank Andreas Nicolai who actually created the BCB project for me and applied some code fixes for that purpose.

Since I'm currently not in posession of BCB future changes may
introduce minor issues in this projects. If this is the case
and you encounter such problems please let me know...



Please note:

The creation of example3.exe requires the presence of the muParser.dll so make sure to copy it to the output directory of the example if it is not present.
