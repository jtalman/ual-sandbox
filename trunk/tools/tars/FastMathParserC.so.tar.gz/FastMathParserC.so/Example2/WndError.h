#pragma once

#include "../ParserLib/muParserBase.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace mu;

namespace Example2
{
  /// <summary> 
	/// Zusammenfassung f�r WndError
	///
	/// Achtung: Wenn Sie den Namen dieser Klasse �ndern, m�ssen Sie die Eigenschaft
	///          'Ressourcendateiname' f�r das Compilertool f�r verwaltete Ressourcen �ndern, 
	///          das allen .resx-Dateien zugewiesen ist, von denen diese Klasse abh�ngt. 
	///          Anderenfalls k�nnen die Designer nicht korrekt mit den lokalisierten Ressourcen
	///          arbeiten, die diesem Formular zugewiesen sind.
	/// </summary>
	public __gc class WndError : public System::Windows::Forms::Form
	{
  public: 
		WndError()
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
  private: System::Windows::Forms::Panel *  paBase;
  private: System::Windows::Forms::Label *  lbCode;
  private: System::Windows::Forms::Label *  lbTok;
  private: System::Windows::Forms::Label *  lbPos;
  private: System::Windows::Forms::Label *  lbMsg;
  private: System::Windows::Forms::Label *  lbTokTag;
  private: System::Windows::Forms::Label *  lbPosTag;
  private: System::Windows::Forms::Label *  lbErrcTag;
  private: System::Windows::Forms::Label *  lbMsgTag;
  private: System::Windows::Forms::PictureBox *  pbGfx;
  private: System::Windows::Forms::Panel *  paSep;
  private: System::Windows::Forms::Label *  lbCaption;
  private: System::Windows::Forms::Button *  btnOK;
  private: System::Windows::Forms::PictureBox *  pbGrad;
  private: System::Windows::Forms::PictureBox *  pbGradBottom;
  private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
      System::Resources::ResourceManager *  resources = new System::Resources::ResourceManager(__typeof(Example2::WndError));
      this->paBase = new System::Windows::Forms::Panel();
      this->pbGrad = new System::Windows::Forms::PictureBox();
      this->btnOK = new System::Windows::Forms::Button();
      this->paSep = new System::Windows::Forms::Panel();
      this->lbCaption = new System::Windows::Forms::Label();
      this->lbCode = new System::Windows::Forms::Label();
      this->lbTok = new System::Windows::Forms::Label();
      this->lbPos = new System::Windows::Forms::Label();
      this->lbMsg = new System::Windows::Forms::Label();
      this->lbTokTag = new System::Windows::Forms::Label();
      this->lbPosTag = new System::Windows::Forms::Label();
      this->lbErrcTag = new System::Windows::Forms::Label();
      this->lbMsgTag = new System::Windows::Forms::Label();
      this->pbGfx = new System::Windows::Forms::PictureBox();
      this->pbGradBottom = new System::Windows::Forms::PictureBox();
      this->paBase->SuspendLayout();
      this->paSep->SuspendLayout();
      this->SuspendLayout();
      // 
      // paBase
      // 
      this->paBase->BackColor = System::Drawing::Color::White;
      this->paBase->Controls->Add(this->pbGrad);
      this->paBase->Controls->Add(this->btnOK);
      this->paBase->Controls->Add(this->paSep);
      this->paBase->Controls->Add(this->lbCode);
      this->paBase->Controls->Add(this->lbTok);
      this->paBase->Controls->Add(this->lbPos);
      this->paBase->Controls->Add(this->lbMsg);
      this->paBase->Controls->Add(this->lbTokTag);
      this->paBase->Controls->Add(this->lbPosTag);
      this->paBase->Controls->Add(this->lbErrcTag);
      this->paBase->Controls->Add(this->lbMsgTag);
      this->paBase->Controls->Add(this->pbGfx);
      this->paBase->Controls->Add(this->pbGradBottom);
      this->paBase->Dock = System::Windows::Forms::DockStyle::Fill;
      this->paBase->Location = System::Drawing::Point(0, 0);
      this->paBase->Name = S"paBase";
      this->paBase->Size = System::Drawing::Size(456, 157);
      this->paBase->TabIndex = 2;
      // 
      // pbGrad
      // 
      this->pbGrad->BackgroundImage = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"pbGrad.BackgroundImage")));
      this->pbGrad->Dock = System::Windows::Forms::DockStyle::Top;
      this->pbGrad->Location = System::Drawing::Point(0, 32);
      this->pbGrad->Name = S"pbGrad";
      this->pbGrad->Size = System::Drawing::Size(456, 15);
      this->pbGrad->TabIndex = 28;
      this->pbGrad->TabStop = false;
      // 
      // btnOK
      // 
      this->btnOK->Anchor = (System::Windows::Forms::AnchorStyles)(System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right);
      this->btnOK->BackColor = System::Drawing::Color::FromArgb((System::Byte)224, (System::Byte)224, (System::Byte)224);
      this->btnOK->DialogResult = System::Windows::Forms::DialogResult::OK;
      this->btnOK->Location = System::Drawing::Point(352, 129);
      this->btnOK->Name = S"btnOK";
      this->btnOK->Size = System::Drawing::Size(96, 24);
      this->btnOK->TabIndex = 27;
      this->btnOK->Text = S"OK";
      // 
      // paSep
      // 
      this->paSep->BackColor = System::Drawing::Color::FromArgb((System::Byte)192, (System::Byte)192, (System::Byte)255);
      this->paSep->Controls->Add(this->lbCaption);
      this->paSep->Dock = System::Windows::Forms::DockStyle::Top;
      this->paSep->Location = System::Drawing::Point(0, 0);
      this->paSep->Name = S"paSep";
      this->paSep->Size = System::Drawing::Size(456, 32);
      this->paSep->TabIndex = 26;
      // 
      // lbCaption
      // 
      this->lbCaption->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 16, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
      this->lbCaption->ForeColor = System::Drawing::Color::FromArgb((System::Byte)0, (System::Byte)0, (System::Byte)64);
      this->lbCaption->Location = System::Drawing::Point(8, 3);
      this->lbCaption->Name = S"lbCaption";
      this->lbCaption->Size = System::Drawing::Size(168, 32);
      this->lbCaption->TabIndex = 18;
      this->lbCaption->Text = S"Parser error";
      // 
      // lbCode
      // 
      this->lbCode->Location = System::Drawing::Point(168, 72);
      this->lbCode->Name = S"lbCode";
      this->lbCode->Size = System::Drawing::Size(288, 16);
      this->lbCode->TabIndex = 25;
      // 
      // lbTok
      // 
      this->lbTok->Location = System::Drawing::Point(168, 104);
      this->lbTok->Name = S"lbTok";
      this->lbTok->Size = System::Drawing::Size(288, 16);
      this->lbTok->TabIndex = 24;
      // 
      // lbPos
      // 
      this->lbPos->Location = System::Drawing::Point(168, 88);
      this->lbPos->Name = S"lbPos";
      this->lbPos->Size = System::Drawing::Size(288, 16);
      this->lbPos->TabIndex = 23;
      // 
      // lbMsg
      // 
      this->lbMsg->Location = System::Drawing::Point(168, 56);
      this->lbMsg->Name = S"lbMsg";
      this->lbMsg->Size = System::Drawing::Size(288, 16);
      this->lbMsg->TabIndex = 22;
      // 
      // lbTokTag
      // 
      this->lbTokTag->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
      this->lbTokTag->Location = System::Drawing::Point(104, 104);
      this->lbTokTag->Name = S"lbTokTag";
      this->lbTokTag->Size = System::Drawing::Size(64, 16);
      this->lbTokTag->TabIndex = 21;
      this->lbTokTag->Text = S"Token:";
      // 
      // lbPosTag
      // 
      this->lbPosTag->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
      this->lbPosTag->Location = System::Drawing::Point(104, 88);
      this->lbPosTag->Name = S"lbPosTag";
      this->lbPosTag->Size = System::Drawing::Size(56, 23);
      this->lbPosTag->TabIndex = 20;
      this->lbPosTag->Text = S"Position:";
      // 
      // lbErrcTag
      // 
      this->lbErrcTag->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
      this->lbErrcTag->Location = System::Drawing::Point(104, 72);
      this->lbErrcTag->Name = S"lbErrcTag";
      this->lbErrcTag->Size = System::Drawing::Size(64, 23);
      this->lbErrcTag->TabIndex = 19;
      this->lbErrcTag->Text = S"Code:";
      // 
      // lbMsgTag
      // 
      this->lbMsgTag->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
      this->lbMsgTag->Location = System::Drawing::Point(104, 56);
      this->lbMsgTag->Name = S"lbMsgTag";
      this->lbMsgTag->Size = System::Drawing::Size(64, 16);
      this->lbMsgTag->TabIndex = 18;
      this->lbMsgTag->Text = S"Message:";
      // 
      // pbGfx
      // 
      this->pbGfx->BackColor = System::Drawing::Color::Transparent;
      this->pbGfx->Image = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"pbGfx.Image")));
      this->pbGfx->Location = System::Drawing::Point(16, 56);
      this->pbGfx->Name = S"pbGfx";
      this->pbGfx->Size = System::Drawing::Size(72, 72);
      this->pbGfx->TabIndex = 16;
      this->pbGfx->TabStop = false;
      // 
      // pbGradBottom
      // 
      this->pbGradBottom->Anchor = (System::Windows::Forms::AnchorStyles)(System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right);
      this->pbGradBottom->Image = (__try_cast<System::Drawing::Image *  >(resources->GetObject(S"pbGradBottom.Image")));
      this->pbGradBottom->Location = System::Drawing::Point(104, 124);
      this->pbGradBottom->Name = S"pbGradBottom";
      this->pbGradBottom->Size = System::Drawing::Size(352, 32);
      this->pbGradBottom->TabIndex = 29;
      this->pbGradBottom->TabStop = false;
      // 
      // WndError
      // 
      this->AcceptButton = this->btnOK;
      this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
      this->ClientSize = System::Drawing::Size(456, 157);
      this->Controls->Add(this->paBase);
      this->MaximizeBox = false;
      this->MinimizeBox = false;
      this->Name = S"WndError";
      this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
      this->Text = S"An error occured...";
      this->TopMost = true;
      this->paBase->ResumeLayout(false);
      this->paSep->ResumeLayout(false);
      this->ResumeLayout(false);

    }		


  public:    
    void Reset(const mu::ParserBase::exception_type *pExc)
    {
      if (pExc)
      {
        lbMsg->Text = pExc->GetMsg().c_str();
        lbTok->Text = pExc->GetToken().c_str();
        lbCode->Text = System::Convert::ToString(pExc->GetCode());
        lbPos->Text = System::Convert::ToString(pExc->GetPos());
      }
      else
      {
        lbMsg->Text = "No Error";
        lbTok->Text = "";
        lbPos->Text = "";
        lbCode->Text = "";
      }
    }
};
}
