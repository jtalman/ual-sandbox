
/* Define if the C++ compiler supports "throw ()" declarations.  */
#undef HAVE_THROW_DECL

