#undef PACKAGE
#undef VERSION
#undef HAVE_LIBZ
#undef HAVE_LIBM
#undef HAVE_ISINF
#undef HAVE_ISNAN
#undef HAVE_LIBHISTORY
#undef HAVE_LIBREADLINE
#undef HAVE_LIBPTHREAD
#undef HAVE_PTHREAD_H

/* Define if IPV6 support is there */
#undef SUPPORT_IP6

/* Define if getaddrinfo is there */
#undef HAVE_GETADDRINFO
